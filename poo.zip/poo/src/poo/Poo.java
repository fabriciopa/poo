/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

/**
 *
 * @author fabricioaraujo
 */

public class Poo {
    public static void main(String[] args) {
        
        Cachorro cachorro = new Cachorro();
        cachorro.setNome("Totó");
        cachorro.setRaca("Golden retriever");
        cachorro.setSexo("Macho");
        cachorro.setIdade(5);
        System.out.println("O nome do cachorro é: "+cachorro.getNome());
        System.out.println("A raça do cachorro é: "+cachorro.getRaca());
        System.out.println("O sexo do cachorro é: "+cachorro.getSexo());
        System.out.println("A idade do cachorro é: "+cachorro.getIdade());
        cachorro.falar();
        cachorro.comer();
        
        Gato gato = new Gato();
        gato.setNome("Babalu");
        gato.setRaca("Siamês");
        gato.setSexo("Fêmea");
        gato.setIdade(2);
        System.out.println("O nome do gato é: "+gato.getNome());
        System.out.println("A raça do gato é: "+gato.getRaca());
        System.out.println("O sexo do gato é: "+gato.getSexo());
        System.out.println("A idade do gato é: "+gato.getIdade());
        gato.falar();
        gato.comer();
        
        Macaco macaco = new Macaco();
        macaco.setNome("Peludinho");
        macaco.setRaca("Orangotango");
        macaco.setSexo("Macho");
        macaco.setIdade(10);
        System.out.println("O nome do macaco é: "+macaco.getNome());
        System.out.println("A raça do macaco é: "+macaco.getRaca());
        System.out.println("O sexo do macaco é: "+macaco.getSexo());
        System.out.println("A idade do macaco é: "+macaco.getIdade());
        macaco.falar();
        macaco.comer();
        
    }
    
}
