/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package poo;

/**
 *
 * @author fabricioaraujo
 */
public class Animal {
    private String nome;
    private String raca;
    private String sexo;
    private int idade;
    
    protected String getNome (){
        return this.nome;
    }
    protected String getRaca (){
        return this.raca;
    }
    protected String getSexo (){
        return this.sexo;
    }
    protected int getIdade (){
        return this.idade;
    }
    protected void setNome (String nome){
        this.nome = nome;
    }
    protected void setRaca (String raca){
        this.raca = raca;
    }
    protected void setSexo (String sexo){
        this.sexo = sexo;
    }
    protected void setIdade (int idade){
        this.idade = idade;
    }
    protected void comer (){
        System.out.println(this.nome + " está comendo");
    }
    protected void falar (){
        System.out.println("Emite som do animal");
    }
}
